const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

router.get('/', productController.getHomePage);
router.get('/recommend', productController.getRecommendations);
router.get('/product/:id', productController.getProductPage);
router.get('/checkout/:id', productController.getCheckoutPage);

module.exports = router;